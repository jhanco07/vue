<template>
    <h1>List Item</h1>
</template>

<script>
export default {
    components:{
        name: 'EditItem'
    }
}
</script>


