<template>
    <h1>Edit Item</h1>
</template>

<script>
export default {
    components:{
        name: 'EditItem'
    }
}
</script>

